function Navlists() {
  return (
    <div className="Navlists">
      {/* <h1>Navlists</h1> */}
      <ul>
        <li>Vehicles</li>
        <li>Launches</li>
        <li>Human Spaceflight</li>
        <li>Rideshare</li>
        <li>Starlink</li>
        <li>Starshield</li>
        <li>Xai</li>
        <li>Company</li>
        <li>Shop</li>
        <li>
          <select name="" id="">
            <option value="Upcoming Launches">Upcoming Launches</option>
          </select>
        </li>
      </ul>
    </div>
  );
}
export default Navlists;
